﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public static class Verificadora
    {
        public static bool VerificarNumero(Numero n, ETipoNumero e)
        {
            bool aux = false;
            switch (e)
            {
                case ETipoNumero.Par:
                    if (n.Valor%2 ==0)
                    {
                        aux = true;
                    }
                    break;
                case ETipoNumero.Impar:
                    if (n.Valor % 2 != 0)
                    {
                        aux = true;
                    }
                    break;
                case ETipoNumero.Positivos:
                    if (n.Valor > 0)
                    {
                        aux = true;
                    }
                    break;
                case ETipoNumero.Negativos:
                    if (n.Valor < 0)
                    {
                        aux = true;
                    }
                    break;
                case ETipoNumero.Cero:
                    if (n.Valor == 0)
                    {
                        aux = true;
                    }
                    break;

            }
            return aux;
        }
    }
}

﻿public enum ETipoNumero
{Par,Impar,Positivos,Negativos,Cero}
public enum ETipoResultado
{ Suma, Resta, Divicion, Multiplicacion }
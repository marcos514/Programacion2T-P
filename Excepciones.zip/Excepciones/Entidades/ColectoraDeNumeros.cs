﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class ColectoraDeNumeros
    {
        private List<Numero> numeros;

        private ColectoraDeNumeros()
        {
            this.numeros = new List<Numero>();
        }

        public ColectoraDeNumeros(ETipoNumero num):this() 
        {
            this.Numeros = num;
        }

        public ETipoNumero Numeros { get; set; }

        public int Suma 
        {
            get
            {
                return (int)ColectoraDeNumeros.ObtenerResultado(this, ETipoResultado.Suma);
            }
        }
        public int Resta
        {
            get
            {
                return (int)ColectoraDeNumeros.ObtenerResultado(this, ETipoResultado.Resta);
            }
        }

        public int Multiplicacion
        {
            get
            {
                return (int) ColectoraDeNumeros.ObtenerResultado(this, ETipoResultado.Multiplicacion);
            }
        }
        public double Divicion
        {
            get
            {
                return ColectoraDeNumeros.ObtenerResultado(this, ETipoResultado.Divicion);
            }
        }

        protected static double ObtenerResultado(ColectoraDeNumeros list,ETipoResultado e)
        {
            Numero aux = list.numeros[0].Valor;
            for (int i = 1; i < list.numeros.Count; i++)
            {
                switch (e)
	            {
		            case ETipoResultado.Suma:
                        
                        aux += list.numeros[i];
                        break;

                     case ETipoResultado.Resta:

                         aux -= list.numeros[i].Valor;
                         break;

                     case ETipoResultado.Multiplicacion:

                         aux *= list.numeros[i].Valor;
                         break;

                     case ETipoResultado.Divicion:
                         aux = (int)(aux /list.numeros[i]);
                        break;
	            }
            }
            return aux.Valor;

            
        }



       


        public static ColectoraDeNumeros operator +(ColectoraDeNumeros col, Numero n)
        {
            ColectoraDeNumeros aux = new ColectoraDeNumeros();
            aux.numeros = col.numeros;
            try
            { 
                if(Verificadora.VerificarNumero(n,col.Numeros))
                {
                    aux.numeros.Add(n);
                }
                else
                {
                    throw new Exception("El numero no puede ingresarse en la coleccion");
                }
            }
            catch(Exception e)
            {
                Console.WriteLine(e.Message);
            }
            
            return aux;
        }

        public static ColectoraDeNumeros operator -(ColectoraDeNumeros col, Numero n)
        {
            ColectoraDeNumeros aux = new ColectoraDeNumeros();
            aux.numeros = col.numeros;
            for (int i = 0; i < aux.numeros.Count;i++)
            {
                if (aux.numeros[i].Valor == n.Valor)
                {
                    aux.numeros.RemoveAt(i);
                    break;
                }
            }
            return aux;
        }

        public override string ToString()
        {
            StringBuilder lista=new StringBuilder();
            foreach(Numero i in this.numeros)
            {
                lista.AppendLine(i.Valor.ToString());
            }
            return lista.ToString();
        }

    }
}

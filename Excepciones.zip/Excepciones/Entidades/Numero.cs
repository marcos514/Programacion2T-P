﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Numero
    {
        protected int _numero;

        public int Valor
        {
            get
            {
                return this._numero;            
            }
        }

        public Numero(int i)
        {
            this._numero = i;
        }

        public static int operator +(Numero uno, Numero dos)
        {
            return uno.Valor + dos.Valor;
        }

        public static int operator -(Numero uno, Numero dos)
        {
            return uno.Valor - dos.Valor;
        }

        public static int operator *(Numero uno, Numero dos)
        {
            return uno.Valor * dos.Valor;
        }

        public static double operator /(Numero uno, Numero dos)
        {
            try
            {
                return uno.Valor / dos.Valor;
            }
            catch(Exception e)
            {
                Console.WriteLine(e.Message);
            }
            return 0;
        }


        public static implicit operator Numero(int i)
        {
            return new Numero(i);
        }

    }
}

﻿namespace Tablero
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.a1 = new System.Windows.Forms.TextBox();
            this.a3 = new System.Windows.Forms.TextBox();
            this.a2 = new System.Windows.Forms.TextBox();
            this.a5 = new System.Windows.Forms.TextBox();
            this.a7 = new System.Windows.Forms.TextBox();
            this.b8 = new System.Windows.Forms.TextBox();
            this.b6 = new System.Windows.Forms.TextBox();
            this.b4 = new System.Windows.Forms.TextBox();
            this.b2 = new System.Windows.Forms.TextBox();
            this.a4 = new System.Windows.Forms.TextBox();
            this.a8 = new System.Windows.Forms.TextBox();
            this.a6 = new System.Windows.Forms.TextBox();
            this.b7 = new System.Windows.Forms.TextBox();
            this.b5 = new System.Windows.Forms.TextBox();
            this.b3 = new System.Windows.Forms.TextBox();
            this.b1 = new System.Windows.Forms.TextBox();
            this.d1 = new System.Windows.Forms.TextBox();
            this.d3 = new System.Windows.Forms.TextBox();
            this.d5 = new System.Windows.Forms.TextBox();
            this.d7 = new System.Windows.Forms.TextBox();
            this.c6 = new System.Windows.Forms.TextBox();
            this.c8 = new System.Windows.Forms.TextBox();
            this.c4 = new System.Windows.Forms.TextBox();
            this.d8 = new System.Windows.Forms.TextBox();
            this.d6 = new System.Windows.Forms.TextBox();
            this.d4 = new System.Windows.Forms.TextBox();
            this.d2 = new System.Windows.Forms.TextBox();
            this.c7 = new System.Windows.Forms.TextBox();
            this.c5 = new System.Windows.Forms.TextBox();
            this.c2 = new System.Windows.Forms.TextBox();
            this.c3 = new System.Windows.Forms.TextBox();
            this.c1 = new System.Windows.Forms.TextBox();
            this.f1 = new System.Windows.Forms.TextBox();
            this.f3 = new System.Windows.Forms.TextBox();
            this.f5 = new System.Windows.Forms.TextBox();
            this.f7 = new System.Windows.Forms.TextBox();
            this.e6 = new System.Windows.Forms.TextBox();
            this.e8 = new System.Windows.Forms.TextBox();
            this.e4 = new System.Windows.Forms.TextBox();
            this.f8 = new System.Windows.Forms.TextBox();
            this.f6 = new System.Windows.Forms.TextBox();
            this.f4 = new System.Windows.Forms.TextBox();
            this.f2 = new System.Windows.Forms.TextBox();
            this.e7 = new System.Windows.Forms.TextBox();
            this.e5 = new System.Windows.Forms.TextBox();
            this.e2 = new System.Windows.Forms.TextBox();
            this.e3 = new System.Windows.Forms.TextBox();
            this.e1 = new System.Windows.Forms.TextBox();
            this.textBox9 = new System.Windows.Forms.TextBox();
            this.textBox10 = new System.Windows.Forms.TextBox();
            this.textBox11 = new System.Windows.Forms.TextBox();
            this.textBox12 = new System.Windows.Forms.TextBox();
            this.textBox13 = new System.Windows.Forms.TextBox();
            this.textBox14 = new System.Windows.Forms.TextBox();
            this.g4 = new System.Windows.Forms.TextBox();
            this.textBox16 = new System.Windows.Forms.TextBox();
            this.textBox17 = new System.Windows.Forms.TextBox();
            this.textBox18 = new System.Windows.Forms.TextBox();
            this.textBox19 = new System.Windows.Forms.TextBox();
            this.textBox20 = new System.Windows.Forms.TextBox();
            this.g = new System.Windows.Forms.TextBox();
            this.g2 = new System.Windows.Forms.TextBox();
            this.g3 = new System.Windows.Forms.TextBox();
            this.g1 = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // a1
            // 
            this.a1.Location = new System.Drawing.Point(5, 5);
            this.a1.Name = "a1";
            this.a1.Size = new System.Drawing.Size(23, 20);
            this.a1.TabIndex = 0;
            // 
            // a3
            // 
            this.a3.Location = new System.Drawing.Point(61, 5);
            this.a3.Name = "a3";
            this.a3.Size = new System.Drawing.Size(23, 20);
            this.a3.TabIndex = 1;
            // 
            // a2
            // 
            this.a2.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.a2.ForeColor = System.Drawing.SystemColors.Window;
            this.a2.Location = new System.Drawing.Point(33, 5);
            this.a2.Name = "a2";
            this.a2.Size = new System.Drawing.Size(23, 20);
            this.a2.TabIndex = 2;
            // 
            // a5
            // 
            this.a5.Location = new System.Drawing.Point(117, 5);
            this.a5.Name = "a5";
            this.a5.Size = new System.Drawing.Size(23, 20);
            this.a5.TabIndex = 4;
            // 
            // a7
            // 
            this.a7.Location = new System.Drawing.Point(173, 5);
            this.a7.Name = "a7";
            this.a7.Size = new System.Drawing.Size(23, 20);
            this.a7.TabIndex = 6;
            // 
            // b8
            // 
            this.b8.Location = new System.Drawing.Point(199, 31);
            this.b8.Name = "b8";
            this.b8.Size = new System.Drawing.Size(23, 20);
            this.b8.TabIndex = 63;
            // 
            // b6
            // 
            this.b6.Location = new System.Drawing.Point(145, 31);
            this.b6.Name = "b6";
            this.b6.Size = new System.Drawing.Size(23, 20);
            this.b6.TabIndex = 61;
            // 
            // b4
            // 
            this.b4.Location = new System.Drawing.Point(90, 31);
            this.b4.Name = "b4";
            this.b4.Size = new System.Drawing.Size(23, 20);
            this.b4.TabIndex = 59;
            // 
            // b2
            // 
            this.b2.Location = new System.Drawing.Point(33, 31);
            this.b2.Name = "b2";
            this.b2.Size = new System.Drawing.Size(23, 20);
            this.b2.TabIndex = 58;
            // 
            // a4
            // 
            this.a4.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.a4.ForeColor = System.Drawing.SystemColors.Window;
            this.a4.Location = new System.Drawing.Point(90, 5);
            this.a4.Name = "a4";
            this.a4.Size = new System.Drawing.Size(23, 20);
            this.a4.TabIndex = 118;
            // 
            // a8
            // 
            this.a8.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.a8.ForeColor = System.Drawing.SystemColors.Window;
            this.a8.Location = new System.Drawing.Point(199, 5);
            this.a8.Name = "a8";
            this.a8.Size = new System.Drawing.Size(23, 20);
            this.a8.TabIndex = 119;
            // 
            // a6
            // 
            this.a6.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.a6.ForeColor = System.Drawing.SystemColors.Window;
            this.a6.Location = new System.Drawing.Point(145, 5);
            this.a6.Name = "a6";
            this.a6.Size = new System.Drawing.Size(23, 20);
            this.a6.TabIndex = 120;
            // 
            // b7
            // 
            this.b7.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.b7.ForeColor = System.Drawing.SystemColors.Window;
            this.b7.Location = new System.Drawing.Point(174, 31);
            this.b7.Name = "b7";
            this.b7.Size = new System.Drawing.Size(23, 20);
            this.b7.TabIndex = 121;
            // 
            // b5
            // 
            this.b5.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.b5.ForeColor = System.Drawing.SystemColors.Window;
            this.b5.Location = new System.Drawing.Point(118, 31);
            this.b5.Name = "b5";
            this.b5.Size = new System.Drawing.Size(23, 20);
            this.b5.TabIndex = 122;
            // 
            // b3
            // 
            this.b3.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.b3.ForeColor = System.Drawing.SystemColors.Window;
            this.b3.Location = new System.Drawing.Point(61, 31);
            this.b3.Name = "b3";
            this.b3.Size = new System.Drawing.Size(23, 20);
            this.b3.TabIndex = 123;
            // 
            // b1
            // 
            this.b1.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.b1.ForeColor = System.Drawing.SystemColors.Window;
            this.b1.Location = new System.Drawing.Point(5, 31);
            this.b1.Name = "b1";
            this.b1.Size = new System.Drawing.Size(23, 20);
            this.b1.TabIndex = 124;
            // 
            // d1
            // 
            this.d1.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.d1.ForeColor = System.Drawing.SystemColors.Window;
            this.d1.Location = new System.Drawing.Point(5, 83);
            this.d1.Name = "d1";
            this.d1.Size = new System.Drawing.Size(23, 20);
            this.d1.TabIndex = 140;
            // 
            // d3
            // 
            this.d3.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.d3.ForeColor = System.Drawing.SystemColors.Window;
            this.d3.Location = new System.Drawing.Point(61, 83);
            this.d3.Name = "d3";
            this.d3.Size = new System.Drawing.Size(23, 20);
            this.d3.TabIndex = 139;
            // 
            // d5
            // 
            this.d5.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.d5.ForeColor = System.Drawing.SystemColors.Window;
            this.d5.Location = new System.Drawing.Point(118, 83);
            this.d5.Name = "d5";
            this.d5.Size = new System.Drawing.Size(23, 20);
            this.d5.TabIndex = 138;
            // 
            // d7
            // 
            this.d7.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.d7.ForeColor = System.Drawing.SystemColors.Window;
            this.d7.Location = new System.Drawing.Point(174, 83);
            this.d7.Name = "d7";
            this.d7.Size = new System.Drawing.Size(23, 20);
            this.d7.TabIndex = 137;
            // 
            // c6
            // 
            this.c6.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.c6.ForeColor = System.Drawing.SystemColors.Window;
            this.c6.Location = new System.Drawing.Point(145, 57);
            this.c6.Name = "c6";
            this.c6.Size = new System.Drawing.Size(23, 20);
            this.c6.TabIndex = 136;
            // 
            // c8
            // 
            this.c8.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.c8.ForeColor = System.Drawing.SystemColors.Window;
            this.c8.Location = new System.Drawing.Point(199, 57);
            this.c8.Name = "c8";
            this.c8.Size = new System.Drawing.Size(23, 20);
            this.c8.TabIndex = 135;
            // 
            // c4
            // 
            this.c4.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.c4.ForeColor = System.Drawing.SystemColors.Window;
            this.c4.Location = new System.Drawing.Point(90, 57);
            this.c4.Name = "c4";
            this.c4.Size = new System.Drawing.Size(23, 20);
            this.c4.TabIndex = 134;
            // 
            // d8
            // 
            this.d8.Location = new System.Drawing.Point(199, 83);
            this.d8.Name = "d8";
            this.d8.Size = new System.Drawing.Size(23, 20);
            this.d8.TabIndex = 133;
            // 
            // d6
            // 
            this.d6.Location = new System.Drawing.Point(145, 83);
            this.d6.Name = "d6";
            this.d6.Size = new System.Drawing.Size(23, 20);
            this.d6.TabIndex = 132;
            // 
            // d4
            // 
            this.d4.Location = new System.Drawing.Point(90, 83);
            this.d4.Name = "d4";
            this.d4.Size = new System.Drawing.Size(23, 20);
            this.d4.TabIndex = 131;
            // 
            // d2
            // 
            this.d2.Location = new System.Drawing.Point(33, 83);
            this.d2.Name = "d2";
            this.d2.Size = new System.Drawing.Size(23, 20);
            this.d2.TabIndex = 130;
            // 
            // c7
            // 
            this.c7.Location = new System.Drawing.Point(173, 57);
            this.c7.Name = "c7";
            this.c7.Size = new System.Drawing.Size(23, 20);
            this.c7.TabIndex = 129;
            // 
            // c5
            // 
            this.c5.Location = new System.Drawing.Point(117, 57);
            this.c5.Name = "c5";
            this.c5.Size = new System.Drawing.Size(23, 20);
            this.c5.TabIndex = 128;
            // 
            // c2
            // 
            this.c2.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.c2.ForeColor = System.Drawing.SystemColors.Window;
            this.c2.Location = new System.Drawing.Point(33, 57);
            this.c2.Name = "c2";
            this.c2.Size = new System.Drawing.Size(23, 20);
            this.c2.TabIndex = 127;
            // 
            // c3
            // 
            this.c3.Location = new System.Drawing.Point(61, 57);
            this.c3.Name = "c3";
            this.c3.Size = new System.Drawing.Size(23, 20);
            this.c3.TabIndex = 126;
            // 
            // c1
            // 
            this.c1.Location = new System.Drawing.Point(5, 57);
            this.c1.Name = "c1";
            this.c1.Size = new System.Drawing.Size(23, 20);
            this.c1.TabIndex = 125;
            // 
            // f1
            // 
            this.f1.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.f1.ForeColor = System.Drawing.SystemColors.Window;
            this.f1.Location = new System.Drawing.Point(5, 136);
            this.f1.Name = "f1";
            this.f1.Size = new System.Drawing.Size(23, 20);
            this.f1.TabIndex = 156;
            // 
            // f3
            // 
            this.f3.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.f3.ForeColor = System.Drawing.SystemColors.Window;
            this.f3.Location = new System.Drawing.Point(61, 136);
            this.f3.Name = "f3";
            this.f3.Size = new System.Drawing.Size(23, 20);
            this.f3.TabIndex = 155;
            // 
            // f5
            // 
            this.f5.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.f5.ForeColor = System.Drawing.SystemColors.Window;
            this.f5.Location = new System.Drawing.Point(118, 136);
            this.f5.Name = "f5";
            this.f5.Size = new System.Drawing.Size(23, 20);
            this.f5.TabIndex = 154;
            // 
            // f7
            // 
            this.f7.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.f7.ForeColor = System.Drawing.SystemColors.Window;
            this.f7.Location = new System.Drawing.Point(174, 136);
            this.f7.Name = "f7";
            this.f7.Size = new System.Drawing.Size(23, 20);
            this.f7.TabIndex = 153;
            // 
            // e6
            // 
            this.e6.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.e6.ForeColor = System.Drawing.SystemColors.Window;
            this.e6.Location = new System.Drawing.Point(145, 110);
            this.e6.Name = "e6";
            this.e6.Size = new System.Drawing.Size(23, 20);
            this.e6.TabIndex = 152;
            // 
            // e8
            // 
            this.e8.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.e8.ForeColor = System.Drawing.SystemColors.Window;
            this.e8.Location = new System.Drawing.Point(199, 110);
            this.e8.Name = "e8";
            this.e8.Size = new System.Drawing.Size(23, 20);
            this.e8.TabIndex = 151;
            // 
            // e4
            // 
            this.e4.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.e4.ForeColor = System.Drawing.SystemColors.Window;
            this.e4.Location = new System.Drawing.Point(90, 110);
            this.e4.Name = "e4";
            this.e4.Size = new System.Drawing.Size(23, 20);
            this.e4.TabIndex = 150;
            // 
            // f8
            // 
            this.f8.Location = new System.Drawing.Point(199, 136);
            this.f8.Name = "f8";
            this.f8.Size = new System.Drawing.Size(23, 20);
            this.f8.TabIndex = 149;
            // 
            // f6
            // 
            this.f6.Location = new System.Drawing.Point(145, 136);
            this.f6.Name = "f6";
            this.f6.Size = new System.Drawing.Size(23, 20);
            this.f6.TabIndex = 148;
            // 
            // f4
            // 
            this.f4.Location = new System.Drawing.Point(90, 136);
            this.f4.Name = "f4";
            this.f4.Size = new System.Drawing.Size(23, 20);
            this.f4.TabIndex = 147;
            // 
            // f2
            // 
            this.f2.Location = new System.Drawing.Point(33, 136);
            this.f2.Name = "f2";
            this.f2.Size = new System.Drawing.Size(23, 20);
            this.f2.TabIndex = 146;
            // 
            // e7
            // 
            this.e7.Location = new System.Drawing.Point(173, 110);
            this.e7.Name = "e7";
            this.e7.Size = new System.Drawing.Size(23, 20);
            this.e7.TabIndex = 145;
            // 
            // e5
            // 
            this.e5.Location = new System.Drawing.Point(117, 110);
            this.e5.Name = "e5";
            this.e5.Size = new System.Drawing.Size(23, 20);
            this.e5.TabIndex = 144;
            this.e5.TextChanged += new System.EventHandler(this.textBox37_TextChanged);
            // 
            // e2
            // 
            this.e2.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.e2.ForeColor = System.Drawing.SystemColors.Window;
            this.e2.Location = new System.Drawing.Point(33, 110);
            this.e2.Name = "e2";
            this.e2.Size = new System.Drawing.Size(23, 20);
            this.e2.TabIndex = 143;
            // 
            // e3
            // 
            this.e3.Location = new System.Drawing.Point(61, 110);
            this.e3.Name = "e3";
            this.e3.Size = new System.Drawing.Size(23, 20);
            this.e3.TabIndex = 142;
            // 
            // e1
            // 
            this.e1.Location = new System.Drawing.Point(5, 110);
            this.e1.Name = "e1";
            this.e1.Size = new System.Drawing.Size(23, 20);
            this.e1.TabIndex = 141;
            // 
            // textBox9
            // 
            this.textBox9.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.textBox9.ForeColor = System.Drawing.SystemColors.Window;
            this.textBox9.Location = new System.Drawing.Point(5, 188);
            this.textBox9.Name = "textBox9";
            this.textBox9.Size = new System.Drawing.Size(23, 20);
            this.textBox9.TabIndex = 172;
            // 
            // textBox10
            // 
            this.textBox10.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.textBox10.ForeColor = System.Drawing.SystemColors.Window;
            this.textBox10.Location = new System.Drawing.Point(61, 188);
            this.textBox10.Name = "textBox10";
            this.textBox10.Size = new System.Drawing.Size(23, 20);
            this.textBox10.TabIndex = 171;
            // 
            // textBox11
            // 
            this.textBox11.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.textBox11.ForeColor = System.Drawing.SystemColors.Window;
            this.textBox11.Location = new System.Drawing.Point(118, 188);
            this.textBox11.Name = "textBox11";
            this.textBox11.Size = new System.Drawing.Size(23, 20);
            this.textBox11.TabIndex = 170;
            // 
            // textBox12
            // 
            this.textBox12.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.textBox12.ForeColor = System.Drawing.SystemColors.Window;
            this.textBox12.Location = new System.Drawing.Point(174, 188);
            this.textBox12.Name = "textBox12";
            this.textBox12.Size = new System.Drawing.Size(23, 20);
            this.textBox12.TabIndex = 169;
            // 
            // textBox13
            // 
            this.textBox13.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.textBox13.ForeColor = System.Drawing.SystemColors.Window;
            this.textBox13.Location = new System.Drawing.Point(145, 162);
            this.textBox13.Name = "textBox13";
            this.textBox13.Size = new System.Drawing.Size(23, 20);
            this.textBox13.TabIndex = 168;
            // 
            // textBox14
            // 
            this.textBox14.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.textBox14.ForeColor = System.Drawing.SystemColors.Window;
            this.textBox14.Location = new System.Drawing.Point(199, 162);
            this.textBox14.Name = "textBox14";
            this.textBox14.Size = new System.Drawing.Size(23, 20);
            this.textBox14.TabIndex = 167;
            // 
            // g4
            // 
            this.g4.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.g4.ForeColor = System.Drawing.SystemColors.Window;
            this.g4.Location = new System.Drawing.Point(90, 162);
            this.g4.Name = "g4";
            this.g4.Size = new System.Drawing.Size(23, 20);
            this.g4.TabIndex = 166;
            // 
            // textBox16
            // 
            this.textBox16.Location = new System.Drawing.Point(199, 188);
            this.textBox16.Name = "textBox16";
            this.textBox16.Size = new System.Drawing.Size(23, 20);
            this.textBox16.TabIndex = 165;
            // 
            // textBox17
            // 
            this.textBox17.Location = new System.Drawing.Point(145, 188);
            this.textBox17.Name = "textBox17";
            this.textBox17.Size = new System.Drawing.Size(23, 20);
            this.textBox17.TabIndex = 164;
            // 
            // textBox18
            // 
            this.textBox18.Location = new System.Drawing.Point(90, 188);
            this.textBox18.Name = "textBox18";
            this.textBox18.Size = new System.Drawing.Size(23, 20);
            this.textBox18.TabIndex = 163;
            // 
            // textBox19
            // 
            this.textBox19.Location = new System.Drawing.Point(33, 188);
            this.textBox19.Name = "textBox19";
            this.textBox19.Size = new System.Drawing.Size(23, 20);
            this.textBox19.TabIndex = 162;
            // 
            // textBox20
            // 
            this.textBox20.Location = new System.Drawing.Point(173, 162);
            this.textBox20.Name = "textBox20";
            this.textBox20.Size = new System.Drawing.Size(23, 20);
            this.textBox20.TabIndex = 161;
            // 
            // g
            // 
            this.g.Location = new System.Drawing.Point(117, 162);
            this.g.Name = "g";
            this.g.Size = new System.Drawing.Size(23, 20);
            this.g.TabIndex = 160;
            // 
            // g2
            // 
            this.g2.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.g2.ForeColor = System.Drawing.SystemColors.Window;
            this.g2.Location = new System.Drawing.Point(33, 162);
            this.g2.Name = "g2";
            this.g2.Size = new System.Drawing.Size(23, 20);
            this.g2.TabIndex = 159;
            // 
            // g3
            // 
            this.g3.Location = new System.Drawing.Point(61, 162);
            this.g3.Name = "g3";
            this.g3.Size = new System.Drawing.Size(23, 20);
            this.g3.TabIndex = 158;
            // 
            // g1
            // 
            this.g1.Location = new System.Drawing.Point(5, 162);
            this.g1.Name = "g1";
            this.g1.Size = new System.Drawing.Size(23, 20);
            this.g1.TabIndex = 157;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(561, 449);
            this.Controls.Add(this.textBox9);
            this.Controls.Add(this.textBox10);
            this.Controls.Add(this.textBox11);
            this.Controls.Add(this.textBox12);
            this.Controls.Add(this.textBox13);
            this.Controls.Add(this.textBox14);
            this.Controls.Add(this.g4);
            this.Controls.Add(this.textBox16);
            this.Controls.Add(this.textBox17);
            this.Controls.Add(this.textBox18);
            this.Controls.Add(this.textBox19);
            this.Controls.Add(this.textBox20);
            this.Controls.Add(this.g);
            this.Controls.Add(this.g2);
            this.Controls.Add(this.g3);
            this.Controls.Add(this.g1);
            this.Controls.Add(this.f1);
            this.Controls.Add(this.f3);
            this.Controls.Add(this.f5);
            this.Controls.Add(this.f7);
            this.Controls.Add(this.e6);
            this.Controls.Add(this.e8);
            this.Controls.Add(this.e4);
            this.Controls.Add(this.f8);
            this.Controls.Add(this.f6);
            this.Controls.Add(this.f4);
            this.Controls.Add(this.f2);
            this.Controls.Add(this.e7);
            this.Controls.Add(this.e5);
            this.Controls.Add(this.e2);
            this.Controls.Add(this.e3);
            this.Controls.Add(this.e1);
            this.Controls.Add(this.d1);
            this.Controls.Add(this.d3);
            this.Controls.Add(this.d5);
            this.Controls.Add(this.d7);
            this.Controls.Add(this.c6);
            this.Controls.Add(this.c8);
            this.Controls.Add(this.c4);
            this.Controls.Add(this.d8);
            this.Controls.Add(this.d6);
            this.Controls.Add(this.d4);
            this.Controls.Add(this.d2);
            this.Controls.Add(this.c7);
            this.Controls.Add(this.c5);
            this.Controls.Add(this.c2);
            this.Controls.Add(this.c3);
            this.Controls.Add(this.c1);
            this.Controls.Add(this.b1);
            this.Controls.Add(this.b3);
            this.Controls.Add(this.b5);
            this.Controls.Add(this.b7);
            this.Controls.Add(this.a6);
            this.Controls.Add(this.a8);
            this.Controls.Add(this.a4);
            this.Controls.Add(this.b8);
            this.Controls.Add(this.b6);
            this.Controls.Add(this.b4);
            this.Controls.Add(this.b2);
            this.Controls.Add(this.a7);
            this.Controls.Add(this.a5);
            this.Controls.Add(this.a2);
            this.Controls.Add(this.a3);
            this.Controls.Add(this.a1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox a1;
        private System.Windows.Forms.TextBox a3;
        private System.Windows.Forms.TextBox a2;
        private System.Windows.Forms.TextBox a5;
        private System.Windows.Forms.TextBox a7;
        private System.Windows.Forms.TextBox b8;
        private System.Windows.Forms.TextBox b6;
        private System.Windows.Forms.TextBox b4;
        private System.Windows.Forms.TextBox b2;
        private System.Windows.Forms.TextBox a4;
        private System.Windows.Forms.TextBox a8;
        private System.Windows.Forms.TextBox a6;
        private System.Windows.Forms.TextBox b7;
        private System.Windows.Forms.TextBox b5;
        private System.Windows.Forms.TextBox b3;
        private System.Windows.Forms.TextBox b1;
        private System.Windows.Forms.TextBox d1;
        private System.Windows.Forms.TextBox d3;
        private System.Windows.Forms.TextBox d5;
        private System.Windows.Forms.TextBox d7;
        private System.Windows.Forms.TextBox c6;
        private System.Windows.Forms.TextBox c8;
        private System.Windows.Forms.TextBox c4;
        private System.Windows.Forms.TextBox d8;
        private System.Windows.Forms.TextBox d6;
        private System.Windows.Forms.TextBox d4;
        private System.Windows.Forms.TextBox d2;
        private System.Windows.Forms.TextBox c7;
        private System.Windows.Forms.TextBox c5;
        private System.Windows.Forms.TextBox c2;
        private System.Windows.Forms.TextBox c3;
        private System.Windows.Forms.TextBox c1;
        private System.Windows.Forms.TextBox f1;
        private System.Windows.Forms.TextBox f3;
        private System.Windows.Forms.TextBox f5;
        private System.Windows.Forms.TextBox f7;
        private System.Windows.Forms.TextBox e6;
        private System.Windows.Forms.TextBox e8;
        private System.Windows.Forms.TextBox e4;
        private System.Windows.Forms.TextBox f8;
        private System.Windows.Forms.TextBox f6;
        private System.Windows.Forms.TextBox f4;
        private System.Windows.Forms.TextBox f2;
        private System.Windows.Forms.TextBox e7;
        private System.Windows.Forms.TextBox e5;
        private System.Windows.Forms.TextBox e2;
        private System.Windows.Forms.TextBox e3;
        private System.Windows.Forms.TextBox e1;
        private System.Windows.Forms.TextBox textBox9;
        private System.Windows.Forms.TextBox textBox10;
        private System.Windows.Forms.TextBox textBox11;
        private System.Windows.Forms.TextBox textBox12;
        private System.Windows.Forms.TextBox textBox13;
        private System.Windows.Forms.TextBox textBox14;
        private System.Windows.Forms.TextBox g4;
        private System.Windows.Forms.TextBox textBox16;
        private System.Windows.Forms.TextBox textBox17;
        private System.Windows.Forms.TextBox textBox18;
        private System.Windows.Forms.TextBox textBox19;
        private System.Windows.Forms.TextBox textBox20;
        private System.Windows.Forms.TextBox g;
        private System.Windows.Forms.TextBox g2;
        private System.Windows.Forms.TextBox g3;
        private System.Windows.Forms.TextBox g1;
    }
}


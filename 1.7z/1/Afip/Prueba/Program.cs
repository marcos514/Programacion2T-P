﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Entidades;

namespace Prueba
{
    class Program
    {
        static void Main(string[] args)
        {
            Avion a = new Avion(100, 100);
            Comercial c = new Comercial(100, 100, 200);
            Privado p = new Privado(100, 100, 5);

            Console.WriteLine(((IAfip)a).calcularImpuesto());
            Console.WriteLine(((IAfip)c).calcularImpuesto());
            Console.WriteLine(((IAfip)p).calcularImpuesto());
            Console.ReadLine();

            Console.WriteLine(Gestion.MostrarImpuestoNacional(a));
            Console.WriteLine(Gestion.MostrarImpuestoNacional(c));
            Console.WriteLine(Gestion.MostrarImpuestoNacional(p));
            Console.ReadLine();

        }
    }
}

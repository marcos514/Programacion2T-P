﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Privado:Avion
    {
        protected int _valoracionServicioAbordo;
        public Privado(double p, double v, int ser)
            : base(p, v)
        {
            this._valoracionServicioAbordo = ser;
        }
    }
}

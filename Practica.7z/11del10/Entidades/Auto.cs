﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Auto
    {
        private string _color;
        private string _marca;

        public string Marca
        {
            get { return this._marca; }
        }

        public string Color
        {
            get { return this._color; }
        }

        public static bool operator ==(Auto a, Auto b)
        {
            return (a.Color == b.Color) && (a.Marca == b.Marca);
        }
 
        
        public static bool operator !=(Auto a, Auto b)
        {
            return !(a == b);
        }

        public override string ToString()
        {
            StringBuilder retorno = new StringBuilder();
            retorno.Append("Marca: ");
            retorno.Append(this.Marca);
            retorno.Append(" -- Color: ");
            retorno.Append(this.Color);
            return retorno.ToString();
        }

        public Auto():this("","")
        { }

        public Auto(string color, string marca)
        {
            this._color = color;
            this._marca = marca;
        }

        public override bool Equals(object obj)
        {
            bool retorno = false;
            if (obj is Auto)
            {
                retorno = this == obj;
            }
            return retorno;
        }
    }
}

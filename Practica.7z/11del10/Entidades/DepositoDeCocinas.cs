﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class DepositoDeCocinas
    {
        private int _capacidadMaxima;
        private List<Cocina> _lista;

        public DepositoDeCocinas(int capacidad)
        {
            this._capacidadMaxima = capacidad;
            this._lista = new List<Cocina>();
        }

        public static bool operator +(DepositoDeCocinas lista, Cocina cocina)
        {
            bool aux = false;
            if (lista._lista.Count < lista._capacidadMaxima)
            {
                lista._lista.Add(cocina);
                aux = true;
            }
            return aux;
        }

        private int GetIndice(Cocina a)
        {
            int i = 0;
            for (; i < this._lista.Count; i++)
            {
                if (this._lista[i] == a)
                {
                    break;
                }
            }
            if (i == this._lista.Count)
            {
                i = -1;
            }
            return i;
        }

        public static bool operator -(DepositoDeCocinas deposito, Cocina a)
        {
            int indice = deposito.GetIndice(a);
            bool aux = false;
            if (indice != -1)
            {
                deposito._lista.RemoveAt(indice);
                aux = true;
            }
            return aux;
        }

        public bool Agregar(Cocina a)
        {
            return this + a;
        }

        public bool Remover(Cocina a)
        {
            return this - a;
        }

        public override string ToString()
        {
            StringBuilder retorno = new StringBuilder();
            retorno.Append("Capacidad Maxima : ");
            retorno.AppendLine(this._capacidadMaxima.ToString());
            foreach (Cocina a in this._lista)
            {
                retorno.AppendLine(a.ToString());
            }
            return retorno.ToString();
        }
    }
}

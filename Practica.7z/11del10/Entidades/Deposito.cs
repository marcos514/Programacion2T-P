﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
namespace Entidades
{
    public class Deposito<T> where T : new()
    {
        private int _capacidadMaxima;
        private List<T> _lista;

        public Deposito(int capacidad)
        {
            this._capacidadMaxima = capacidad;
            this._lista = new List<T>();
        }

        public static bool operator +(Deposito<T> lista, T objeto)
        {
            bool aux = false;
            if (lista._lista.Count < lista._capacidadMaxima)
            {
                lista._lista.Add(objeto);
                aux = true;
            }
            return aux;
        }

        private int GetIndice(T a)
        {
            int i = 0;
            for (; i < this._lista.Count; i++)
            {
                if (this._lista[i].Equals(a))
                {
                    break;
                }
            }
            if (i == this._lista.Count)
            {
                i = -1;
            }
            return i;
        }

        public static bool operator -(Deposito<T> deposito, T a)
        {
            int indice = deposito.GetIndice(a);
            bool aux = false;
            if (indice != -1)
            {
                deposito._lista.RemoveAt(indice);
                aux = true;
            }
            return aux;
        }

        public bool Agregar(T a)
        {
            return this + a;
        }

        public bool Remover(T a)
        {
            return this - a;
        }

        public override string ToString()
        {
            StringBuilder retorno = new StringBuilder();
            retorno.Append("Capacidad Maxima : ");
            retorno.AppendLine(this._capacidadMaxima.ToString());
            retorno.Append("Lista de: ");
            retorno.AppendLine( typeof(T).Name);
            foreach (T a in this._lista)
            {
                retorno.AppendLine(a.ToString());
            }
            return retorno.ToString();
        }
        
    }
}

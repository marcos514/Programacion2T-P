﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Cocina
    {
        private int _codigo;
        private bool _esIndustrial;
        private double _precio;

        public int Codigo
        {
            get { return this._codigo; }
        }

        public bool EsIndustrial
        {
            get { return this._esIndustrial; }
        }

        public double Precio
        {
            get { return this._precio; }
        }

        public Cocina():this(0,0,false)
        { 
            
        }
        public Cocina(int codigo, double precio, bool industrial)
        {
            this._codigo = codigo;
            this._esIndustrial = industrial;
            this._precio = precio;
        }

        public static bool operator ==(Cocina a, Cocina b)
        {
            return a.Codigo == b.Codigo;
        }

        public static bool operator !=(Cocina a, Cocina b)
        {
            return !(a == b);
        }

        public override bool Equals(object obj)
        {
            bool aux = false;
            if (obj is Cocina)
            {
                aux = this==obj;
            }

            return aux;
        }

        public override string ToString()
        {
            StringBuilder retorno = new StringBuilder();
            retorno.Append("Codigo: ");
            retorno.Append(this.Codigo.ToString());
            retorno.Append(" -- Precio: ");
            retorno.Append(this.Precio.ToString());
            retorno.Append(" -- Industrial: ");
            retorno.Append(this.EsIndustrial.ToString());
            return retorno.ToString();
        }
    }
}

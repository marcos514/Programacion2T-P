﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class DepositoDeAutos
    {
        private int _capacidadMaxima;
        private List<Auto> _lista;

        public DepositoDeAutos(int cantidad)
        {
            this._capacidadMaxima = cantidad;
            this._lista = new List<Auto>();
        }

        public static bool operator +(DepositoDeAutos lista, Auto auto)
        { 
            bool aux=false;
            if (lista._lista.Count < lista._capacidadMaxima)
            {
                lista._lista.Add(auto);
                aux = true;
            }
            return aux;
        }

        private int GetIndice(Auto a)
        { 
            int i=0;
            for (; i < this._lista.Count; i++)
            {
                if (this._lista[i] == a)
                {
                    break;
                }
            }
            if (i == this._lista.Count)
            {
                i = -1;
            }
            return i;
        }

        public static bool operator -(DepositoDeAutos deposito, Auto a)
        {
            int indice = deposito.GetIndice(a);
            bool aux = false;
            if (indice != -1)
            {
                deposito._lista.RemoveAt(indice);
                aux = true;
            }
            return aux;
        }

        public bool Agregar(Auto a)
        {
            return this+a;
        }

        public bool Remover(Auto a)
        {
            return this - a;
        }

        public override string ToString()
        {
            StringBuilder retorno = new StringBuilder();
            retorno.Append("Capacidad Maxima : ");
            retorno.AppendLine(this._capacidadMaxima.ToString());
            foreach (Auto a in this._lista)
            {
                retorno.AppendLine(a.ToString());
            }
            return retorno.ToString();
        }
    }
}

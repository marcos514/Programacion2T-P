﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Centralita.v2
{
    public class Provincial : Llamada
    {
        protected Franja _franjaHoraria;

        public override float CostoLlamada
        {
            get
            {
                return this.CalcularCosto();
            }
        }

        private float CalcularCosto()
        {
            float aux = 0;
            if (this._franjaHoraria == Franja.Franja_1)
            {
                aux = 0.99f;
            }
            else if (this._franjaHoraria == Franja.Franja_2)
            {
                aux = 1.25f;
            }
            else
            {
                aux = 0.66f;
            }
            return base.Duracion * aux;
        }


        public Provincial(string origen, Franja miFranja, string destino, DateTime duracion)
            : base(origen, destino, duracion)
        {
            this._franjaHoraria = miFranja;
        }

        public Provincial(Llamada unaLlamada, Franja miFranja)
            : this(unaLlamada.Origen, miFranja, unaLlamada.Destino, unaLlamada.fechaInicio)
        {

        }

        protected override string Mostrar()
        {
            return base.Mostrar() + "\tFranja: " + this._franjaHoraria + "\tCosto llamada: " + this.CostoLlamada;
        }

        public override string ToString()
        {
            return this.Mostrar();
        }

        public override bool Equals(object obj)
        {

            return obj is Provincial;
        }

    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Centralita.v2
{
    public abstract class Llamada
    {
        public DateTime fechaInicio;
        protected string _nroDestino;
        protected string _nroOrigen;

        public abstract float CostoLlamada
        {
            get;

        }

        public int Duracion
        {
            get
            {
                TimeSpan aux = DateTime.Now - this.fechaInicio;
                return (int) aux.TotalSeconds;
           }
        }

        public string Destino
        {
            get
            {
                return this._nroDestino;
            }

        }


        public string Origen
        {
            get
            {
                return this._nroOrigen;
            }

        }


        public Llamada(string origen, string destino, DateTime duracion)
        {
            this.fechaInicio = duracion;
            this._nroDestino = destino;
            this._nroOrigen = origen;
        }


        protected virtual string Mostrar()
        {
            return "Origen: " + this.Origen + "\nDestino: " + this.Destino + "\nDuracion: " + this.Duracion;
        }



        public static int OrdenarPorDuracion(Llamada llamada1, Llamada llamada2)
        {
            int aux = 0;
            if (llamada1.Duracion < llamada2.Duracion)
            {
                aux = -1;
            }
            else if (llamada1.Duracion > llamada2.Duracion)
            {
                aux = 1;
            }
            return aux;

        }



        public static bool operator ==(Llamada llamada1, Llamada llamada2)
        {
            return (llamada1._nroOrigen == llamada2._nroOrigen) && (llamada1._nroDestino == llamada2._nroDestino) && llamada1.Equals(llamada2);
        }

        public static bool operator !=(Llamada llamada1, Llamada llamada2)
        {
            return !(llamada1 == llamada2);
        }


    }
}

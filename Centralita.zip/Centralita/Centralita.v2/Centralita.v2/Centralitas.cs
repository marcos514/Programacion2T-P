﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Centralita.v2
{
    public class Centralitas
    {
        private List<Llamada> _listaLlamadas;
        protected string _razonSocial;


        public List<Llamada> Llamadas
        {
            get
            {
                return this._listaLlamadas;
            }
        }

        public float GananciaLocal
        {
            get
            {
                return CalcularGanancia(TipoLlamada.Local);
            }
        }

        public float GananciaProvincial
        {
            get
            {
                return CalcularGanancia(TipoLlamada.Provincial);
            }
        }

        public float GananciaTotal
        {
            get
            {
                return CalcularGanancia(TipoLlamada.Todas);
            }
        }


        private float CalcularGanancia(TipoLlamada tipo)
        {
            float total = 0;
            float totalLocal = 0;
            float totalProvincial = 0;
            List<Llamada> list;
            list = this.Llamadas;

            foreach (Llamada llamada in list)
            {
                if (llamada is Local)
                {
                    totalLocal += llamada.CostoLlamada;
                }
                else if (llamada is Provincial)
                {
                    totalProvincial += llamada.CostoLlamada;
                }
            }

            switch (tipo)
            {
                case TipoLlamada.Local:
                    total = totalLocal;
                    break;
                case TipoLlamada.Provincial:
                    total = totalProvincial;
                    break;
                case TipoLlamada.Todas:
                    total = totalLocal;
                    total += totalProvincial;
                    break;
                default:
                    break;
            }


            return total;
        }

        public Centralitas()
            : this("")
        {
        }

        public Centralitas(string NombreEmpresa)
        {
            this._listaLlamadas = new List<Llamada>();
            this._razonSocial = NombreEmpresa;
        }

        public string Mostrar()
        {
            StringBuilder retorno = new StringBuilder();
            List<Llamada> lista = this.Llamadas;
            Local llamadaLocal;
            Provincial llamadaProvincial;

            foreach (Llamada llamada in lista)
            {
                if (llamada is Local)
                {
                    llamadaLocal = (Local)llamada;
                    retorno.AppendLine(llamadaLocal.ToString());
                }
                else
                {
                    llamadaProvincial = (Provincial)llamada;
                    retorno.AppendLine(llamadaProvincial.ToString());
                }
            }

            return retorno.ToString();
        }

        public void OrdenarLlamadas()
        {
            List<Llamada> lista = this.Llamadas;

            lista.Sort(Llamada.OrdenarPorDuracion);
        }


        private void AgregarLlamda(Llamada llamada)
        {
            this._listaLlamadas.Add(llamada);
        }


        public static bool operator ==(Centralitas central, Llamada llamada)
        {
            bool retorno = false;
            foreach (Llamada llamadaAux in central.Llamadas)
            {
                if (llamadaAux == llamada)
                {
                    retorno = true;
                    break;
                }
            }
            return retorno;
        }

        public static bool operator !=(Centralitas central, Llamada llamada)
        {
            return !(central == llamada);
        }


        public static Centralitas operator +(Centralitas central, Llamada llamada)
        {
            Centralitas centralAux = new Centralitas(central._razonSocial);
            centralAux._listaLlamadas = central._listaLlamadas;
            if (centralAux != llamada)
            {
                centralAux.Llamadas.Add(llamada);
            }
            return centralAux;
        }

    }
}

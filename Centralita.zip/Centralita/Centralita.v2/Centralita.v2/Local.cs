﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Centralita.v2
{
    public class Local : Llamada
    {
        protected float _costo;

        public override float CostoLlamada
        {
            get           
            {
                return base.Duracion*this._costo;
            }
        }

        public Local(string origen, DateTime duracion, string destino, float costo)
            : base(origen, destino, duracion)
        {
            this._costo = costo;
        }


        public Local(Llamada unaLlamada, float costo)
            : this(unaLlamada.Origen, unaLlamada.fechaInicio, unaLlamada.Destino, costo)
        {

        }

        protected override string Mostrar()
        {
            StringBuilder retorno = new StringBuilder();
            retorno.Append(base.Mostrar());
            retorno.Append("\tCosto total: ");
            retorno.Append(this.CostoLlamada.ToString());
            return retorno.ToString();
        }

        public override string ToString()
        {
            return this.Mostrar();
        }

        public override bool Equals(object obj)
        {
            return obj is Local;
        }


    }
}

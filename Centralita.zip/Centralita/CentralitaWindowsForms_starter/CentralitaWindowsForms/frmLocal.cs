﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Centralita.v2;

namespace CentralitaWindowsForms
{
    public partial class frmLocal : frmLlamada
    {
        Local llamadaLocal;
        public frmLocal()
        {
            InitializeComponent();
            
        }

        public override Llamada llamadas
        {
            get
            { return this.llamadaLocal; }
        }

        protected override void btnAceptar_Click(object sender, EventArgs e)
        {

            float auxPrecio;
            if (float.TryParse(this.txtCosto.Text, out auxPrecio))
            {
                this.llamadaLocal = new Local(this.txtOrigen.Text, Convert.ToDateTime(this.txtDuracion.Text), this.txtDestino.Text, auxPrecio);
            
            }
            base.btnAceptar_Click(sender, e);
        }

        protected override void btnCancelar_Click(object sender, EventArgs e)
        {
            base.btnCancelar_Click(sender, e);
        }
    }
}

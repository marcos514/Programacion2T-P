﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Centralita.v2;
namespace CentralitaWindowsForms
{
    public partial class frmProvincial : frmLlamada
    {
        Provincial provincia;

        public frmProvincial()
        {
            InitializeComponent();

            foreach (Franja f in Enum.GetValues(typeof(Franja)))
            {
                this.cmbFranja.Items.Add((int)f);
            }
            
        }


        public override Llamada llamadas
        {
            get
            { return this.provincia; }
        }

        protected override void btnAceptar_Click(object sender, EventArgs e)
        {

            this.provincia = new Provincial(this.txtOrigen.Text, (Franja)int.Parse(this.cmbFranja.Text), this.txtDestino.Text,Convert.ToDateTime( this.txtDuracion.Text));
            base.btnAceptar_Click(sender, e);
        }

    }
}

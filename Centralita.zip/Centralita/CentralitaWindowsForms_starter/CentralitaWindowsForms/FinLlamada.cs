﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Centralita.v2;
namespace CentralitaWindowsForms
{
    public partial class FinLlamada : frmLlamada
    {
        public FinLlamada(Llamada l)
        {
            InitializeComponent();
            this.txtDestino.Text = l.Destino;
            this.txtDuracion.Text = l.fechaInicio.ToString();
            this.txtOrigen.Text = l.Origen;
            this.txtFin.Text = l.CostoLlamada.ToString();
            this.txtDestino.Enabled = false;
            this.txtDuracion.Enabled = false;
            this.txtOrigen.Enabled = false;
            this.txtFin.Enabled = false;
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Entidades;
using System.IO;
namespace winodwsVentana
{
    public partial class Form1 : Form
    {
        Persona persona;
        public Form1()
        {
            InitializeComponent();
            persona = new Persona("Marcos", "Rey");
        }

        private void guardarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            saveFileDialog1.InitialDirectory = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);
            saveFileDialog1.ShowDialog();
           

        }

        private void leerToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void guardarToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            saveFileDialog1.InitialDirectory = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);
            if (saveFileDialog1.ShowDialog() == DialogResult.OK)
            {
                using (StreamWriter archivo = new StreamWriter(saveFileDialog1.FileName, true))
                {
                    archivo.WriteLine(this.persona.ToString());
                }
            }
        }

        private void leerToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            openFileDialog1.ShowDialog();
            string a;
            using (StreamReader archivo = new StreamReader(openFileDialog1.FileName))
            {
                string union = "";
                while ((a = archivo.ReadLine()) != null)
                {
                    union += a;
                    union += "\n";
                }

                MessageBox.Show(union);

            }
        }
    }
}

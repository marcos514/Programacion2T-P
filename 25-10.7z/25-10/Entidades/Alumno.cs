﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Alumno:Persona
    {
        private int _legajo;

        public int Legajo
        {
            get { return this._legajo; }
            set { this._legajo = value; }
        }

        public Alumno()
            : base()
        { }

        public Alumno(int l,Persona a):base(a.Nombre,a.Apellido)
        {
            this._legajo = l;
        }

        public override string ToString()
        {
            return base.ToString()+" "+this._legajo.ToString();
        }
    }
}

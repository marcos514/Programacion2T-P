﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Entidades;
using System.IO;
using System.Xml.Serialization;

namespace prueba
{
    class Program
    {
        static void Main(string[] args)
        {
            List<Persona> lista=new List<Persona>();
            for (int j = 0; j < 3; j++)
            {
                Persona persona1 = new Persona("Marcos", "Rey");
                Alumno a = new Alumno(5 +j, persona1);
                lista.Add(a);
                persona1 = new Persona("Juan", "Pepe");
                a = new Alumno(6 + j, persona1);
                lista.Add(a);
                persona1 = new Persona("Don", "Juan");
                a = new Alumno(7 + j, persona1);
                lista.Add(a);
            }
            XmlSerializer serializados = new XmlSerializer(typeof(List<Persona>));
            TextWriter hola = new StreamWriter(AppDomain.CurrentDomain.BaseDirectory+"\\aaa.xml");
            serializados.Serialize(hola, lista);
            hola.Close();

            TextReader chau = new StreamReader(AppDomain.CurrentDomain.BaseDirectory + "\\aaa.xml");
            List<Persona> lista2=(List<Persona>)serializados.Deserialize(chau);
           
            foreach (Persona i in lista2)
            {
                Console.WriteLine(i.ToString());
            }

            Console.ReadLine();
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            /* linea =  Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);
            using(StreamWriter archivo = new StreamWriter(linea+"\\persona.txt",true))
            {
                archivo.WriteLine(persona1.ToString());
            }
            using (StreamReader archivoLeer = new StreamReader(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments) + "\\persona.txt"))
            {
                while ((linea=archivoLeer.ReadLine())!=null)
                {
                  Console.WriteLine(linea);
                }  
                Console.Read();
            }*/
           
        }
    }
}

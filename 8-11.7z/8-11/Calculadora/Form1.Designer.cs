﻿namespace Calculadora
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this._2 = new System.Windows.Forms.Button();
            this._3 = new System.Windows.Forms.Button();
            this._4 = new System.Windows.Forms.Button();
            this._5 = new System.Windows.Forms.Button();
            this._6 = new System.Windows.Forms.Button();
            this._7 = new System.Windows.Forms.Button();
            this._8 = new System.Windows.Forms.Button();
            this._9 = new System.Windows.Forms.Button();
            this.botonBorrar = new System.Windows.Forms.Button();
            this._0 = new System.Windows.Forms.Button();
            this.igual = new System.Windows.Forms.Button();
            this.suma = new System.Windows.Forms.Button();
            this.multiplicacion = new System.Windows.Forms.Button();
            this.resta = new System.Windows.Forms.Button();
            this.divicion = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.button2 = new System.Windows.Forms.Button();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // _2
            // 
            this._2.Location = new System.Drawing.Point(63, 9);
            this._2.Name = "_2";
            this._2.Size = new System.Drawing.Size(39, 40);
            this._2.TabIndex = 1;
            this._2.Text = "2";
            this._2.UseVisualStyleBackColor = true;
            // 
            // _3
            // 
            this._3.Location = new System.Drawing.Point(108, 9);
            this._3.Name = "_3";
            this._3.Size = new System.Drawing.Size(39, 40);
            this._3.TabIndex = 2;
            this._3.Text = "3";
            this._3.UseVisualStyleBackColor = true;
            // 
            // _4
            // 
            this._4.Location = new System.Drawing.Point(18, 55);
            this._4.Name = "_4";
            this._4.Size = new System.Drawing.Size(39, 40);
            this._4.TabIndex = 3;
            this._4.Text = "4";
            this._4.UseVisualStyleBackColor = true;
            // 
            // _5
            // 
            this._5.Location = new System.Drawing.Point(63, 55);
            this._5.Name = "_5";
            this._5.Size = new System.Drawing.Size(39, 40);
            this._5.TabIndex = 4;
            this._5.Text = "5";
            this._5.UseVisualStyleBackColor = true;
            // 
            // _6
            // 
            this._6.Location = new System.Drawing.Point(108, 55);
            this._6.Name = "_6";
            this._6.Size = new System.Drawing.Size(39, 40);
            this._6.TabIndex = 5;
            this._6.Text = "6";
            this._6.UseVisualStyleBackColor = true;
            // 
            // _7
            // 
            this._7.Location = new System.Drawing.Point(18, 101);
            this._7.Name = "_7";
            this._7.Size = new System.Drawing.Size(39, 40);
            this._7.TabIndex = 6;
            this._7.Text = "7";
            this._7.UseVisualStyleBackColor = true;
            // 
            // _8
            // 
            this._8.Location = new System.Drawing.Point(63, 101);
            this._8.Name = "_8";
            this._8.Size = new System.Drawing.Size(39, 40);
            this._8.TabIndex = 7;
            this._8.Text = "8";
            this._8.UseVisualStyleBackColor = true;
            // 
            // _9
            // 
            this._9.Location = new System.Drawing.Point(108, 101);
            this._9.Name = "_9";
            this._9.Size = new System.Drawing.Size(39, 40);
            this._9.TabIndex = 8;
            this._9.Text = "9";
            this._9.UseVisualStyleBackColor = true;
            // 
            // botonBorrar
            // 
            this.botonBorrar.Location = new System.Drawing.Point(18, 147);
            this.botonBorrar.Name = "botonBorrar";
            this.botonBorrar.Size = new System.Drawing.Size(66, 40);
            this.botonBorrar.TabIndex = 9;
            this.botonBorrar.Text = "C";
            this.botonBorrar.UseVisualStyleBackColor = true;
            // 
            // _0
            // 
            this._0.Location = new System.Drawing.Point(90, 147);
            this._0.Name = "_0";
            this._0.Size = new System.Drawing.Size(57, 40);
            this._0.TabIndex = 10;
            this._0.Text = "0";
            this._0.UseVisualStyleBackColor = true;
            // 
            // igual
            // 
            this.igual.Location = new System.Drawing.Point(18, 197);
            this.igual.Name = "igual";
            this.igual.Size = new System.Drawing.Size(129, 40);
            this.igual.TabIndex = 11;
            this.igual.Text = "=";
            this.igual.UseVisualStyleBackColor = true;
            // 
            // suma
            // 
            this.suma.Location = new System.Drawing.Point(209, 68);
            this.suma.Name = "suma";
            this.suma.Size = new System.Drawing.Size(39, 40);
            this.suma.TabIndex = 12;
            this.suma.Text = "+";
            this.suma.UseVisualStyleBackColor = true;
            // 
            // multiplicacion
            // 
            this.multiplicacion.Location = new System.Drawing.Point(210, 206);
            this.multiplicacion.Name = "multiplicacion";
            this.multiplicacion.Size = new System.Drawing.Size(39, 40);
            this.multiplicacion.TabIndex = 13;
            this.multiplicacion.Text = "*";
            this.multiplicacion.UseVisualStyleBackColor = true;
            // 
            // resta
            // 
            this.resta.Location = new System.Drawing.Point(210, 139);
            this.resta.Name = "resta";
            this.resta.Size = new System.Drawing.Size(39, 40);
            this.resta.TabIndex = 14;
            this.resta.Text = "-";
            this.resta.UseVisualStyleBackColor = true;
            // 
            // divicion
            // 
            this.divicion.Location = new System.Drawing.Point(210, 268);
            this.divicion.Name = "divicion";
            this.divicion.Size = new System.Drawing.Size(39, 40);
            this.divicion.TabIndex = 15;
            this.divicion.Text = "/";
            this.divicion.UseVisualStyleBackColor = true;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(25, 21);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(223, 20);
            this.textBox1.TabIndex = 16;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.button2);
            this.panel2.Controls.Add(this._2);
            this.panel2.Controls.Add(this._3);
            this.panel2.Controls.Add(this._4);
            this.panel2.Controls.Add(this._5);
            this.panel2.Controls.Add(this._6);
            this.panel2.Controls.Add(this.igual);
            this.panel2.Controls.Add(this._7);
            this.panel2.Controls.Add(this.botonBorrar);
            this.panel2.Controls.Add(this._0);
            this.panel2.Controls.Add(this._8);
            this.panel2.Controls.Add(this._9);
            this.panel2.Location = new System.Drawing.Point(25, 68);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(160, 240);
            this.panel2.TabIndex = 17;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(18, 9);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(39, 40);
            this.button2.TabIndex = 12;
            this.button2.Text = "1";
            this.button2.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(265, 326);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.divicion);
            this.Controls.Add(this.resta);
            this.Controls.Add(this.multiplicacion);
            this.Controls.Add(this.suma);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.panel2.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button _2;
        private System.Windows.Forms.Button _3;
        private System.Windows.Forms.Button _4;
        private System.Windows.Forms.Button _5;
        private System.Windows.Forms.Button _6;
        private System.Windows.Forms.Button _7;
        private System.Windows.Forms.Button _8;
        private System.Windows.Forms.Button _9;
        private System.Windows.Forms.Button botonBorrar;
        private System.Windows.Forms.Button _0;
        private System.Windows.Forms.Button igual;
        private System.Windows.Forms.Button suma;
        private System.Windows.Forms.Button multiplicacion;
        private System.Windows.Forms.Button resta;
        private System.Windows.Forms.Button divicion;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button button2;
    }
}


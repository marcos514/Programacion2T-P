﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Entidades;
namespace Calculadora
{
    public delegate double Sumar(double a,double b);
    public delegate double Resta(double a,double b);
    public delegate double Divicion(double a,double b);
    public delegate double Multiplicacion(double a,double b);
    public delegate bool Archivo(string s);
    public partial class Form1 : Form
    {
        event Sumar calSuma;
        event Resta calResta;
        event Divicion calDiv;
        event Multiplicacion calMult;
        event Archivo saveArchivo;

        string archivo;
        List<double> numeros;
        List<string> operadores;
        double resultado;
        private void CambiarOperadoresTrue()
        {
            this.suma.Enabled = true;
            this.resta.Enabled = true;
            this.multiplicacion.Enabled = true;
            this.divicion.Enabled = true;
        }
        private void CambiarOperadoresFalse()
        {
            this.suma.Enabled = false;
            this.resta.Enabled = false;
            this.multiplicacion.Enabled = false;
            this.divicion.Enabled = false;
        }
        public void Calcular(object a)
        {
            this.resultado +=(double) a;
        }
        private void Mostrar(object a,EventArgs b)
        {
            if (a == this._0)
            {
                this.igual.Click += this.Mostrar;
                this.CambiarOperadoresTrue();
                this.textBox1.Text += "0";
                this.numeros[this.numeros.Count-1]=this.numeros[this.numeros.Count-1]*10+0;
            }
            else if (a == this.button2)
            {
                this.igual.Click += this.Mostrar;
                this.CambiarOperadoresTrue();
                this.textBox1.Text += "1";
                this.numeros[this.numeros.Count - 1] = this.numeros[this.numeros.Count - 1] * 10 + 1;
            }
            else if (a == this._2)
            {
                this.igual.Click += this.Mostrar;
                this.CambiarOperadoresTrue();
                this.textBox1.Text += "2";
                this.numeros[this.numeros.Count - 1] = this.numeros[this.numeros.Count - 1] * 10 + 2;
            }
            else if (a == this._3)
            {
                this.igual.Click += this.Mostrar;
                this.CambiarOperadoresTrue();
                this.textBox1.Text += "3";
                this.numeros[this.numeros.Count - 1] = this.numeros[this.numeros.Count - 1] * 10 + 3;
            }
            else if (a == this._4)
            {
                this.igual.Click += this.Mostrar;
                this.CambiarOperadoresTrue();
                this.textBox1.Text += "4";
                this.numeros[this.numeros.Count - 1] = this.numeros[this.numeros.Count - 1] * 10 + 4;
            }
            else if (a == this._5)
            {
                this.igual.Click += this.Mostrar;
                this.CambiarOperadoresTrue();
                this.textBox1.Text += "5";
                this.numeros[this.numeros.Count - 1] = this.numeros[this.numeros.Count - 1] * 10 + 5;
            }
            else if (a == this._6)
            {
                this.igual.Click += this.Mostrar;
                this.CambiarOperadoresTrue();
                this.textBox1.Text += "6";
                this.numeros[this.numeros.Count - 1] = this.numeros[this.numeros.Count - 1] * 10 + 6;
            }
            else if (a == this._7)
            {
                this.igual.Click += this.Mostrar;
                this.CambiarOperadoresTrue();
                this.textBox1.Text += "7";
                this.numeros[this.numeros.Count - 1] = this.numeros[this.numeros.Count - 1] * 10 + 7;
            }
            else if (a == this._8)
            {
                this.igual.Click += this.Mostrar;
                this.CambiarOperadoresTrue();
                this.textBox1.Text += "8";
                this.numeros[this.numeros.Count - 1] = this.numeros[this.numeros.Count - 1] * 10 + 8;
            }
            else if (a == this._9)
            {
                this.igual.Click += this.Mostrar;
                this.CambiarOperadoresTrue();
                this.textBox1.Text += "9";
                this.numeros[this.numeros.Count - 1] = this.numeros[this.numeros.Count - 1] * 10 + 9;
            }
            else if (a == this.suma)
            {
                this.igual.Click -= this.Mostrar;
                this.CambiarOperadoresFalse();
                this.textBox1.Text += "+";
                this.operadores.Add("+");
                this.numeros.Add(0);
            }
            else if (a == this.resta)
            {
                this.igual.Click -= this.Mostrar;
                this.CambiarOperadoresFalse();
                this.textBox1.Text += "-";
                this.operadores.Add("-");
                this.numeros.Add(0);
            }
            else if (a == this.divicion)
            {
                this.igual.Click -= this.Mostrar;
                this.CambiarOperadoresFalse();
                this.textBox1.Text += "/";
                this.operadores.Add("/");
                this.numeros.Add(0);
            }
            else if (a == this.multiplicacion)
            {
                this.igual.Click -= this.Mostrar;
                this.CambiarOperadoresFalse();
                this.textBox1.Text += "*";
                this.operadores.Add("*");
                this.numeros.Add(0);
            }
            else if (a == this.botonBorrar)
            {
                this.CambiarOperadoresFalse();
                this.textBox1.Text = "";
                this.resultado = 0;
                this.CambiarOperadoresFalse();
                this.igual.Enabled = true;
                foreach (Control i in this.panel2.Controls)
                {
                    i.Click += this.Mostrar;
                }
                this.botonBorrar.Click -= this.Mostrar;
                this.igual.Click -= this.Mostrar;

            }
            else if (a == this.igual)
            {
                this.CalcularTodo();
                this.textBox1.Text = ""+this.resultado.ToString();
                this.CambiarOperadoresFalse();
                foreach (Control i in this.panel2.Controls)
                {
                    i.Click -= this.Mostrar;
                }
                this.botonBorrar.Click += this.Mostrar;

            }


        }

        private void CalcularTodo()
        {
            Calculadoras calcu = new Calculadoras();
            bool aux = false;
            archivo += DateTime.Now.ToString()+"\t";
            int auxint=0;
            foreach (double i in this.numeros)
            {
                archivo += i.ToString();
                if (auxint < this.operadores.Count)
                {
                    archivo += this.operadores[auxint];
                }
                auxint++;
            }

            for (int i = 0; i < this.operadores.Count;i++)
            {
                switch (this.operadores[i])
                {
                    case "/":
                        this.numeros[i]= this.calDiv(this.numeros[i], this.numeros[i + 1]);
                        this.numeros.RemoveAt(i+1);
                        this.operadores.RemoveAt(i);
                        i--;
                        break;
                    case "*":
                        this.numeros[i]= this.calMult(this.numeros[i], this.numeros[i + 1]);
                        this.numeros.RemoveAt(i+1);
                        this.operadores.RemoveAt(i);
                        i--;
                        break;
                }
            }
            this.resultado = 0;
            if (this.operadores.Count > 0)
            {
                switch (this.operadores[0])
                {
                    case "+":
                        resultado += this.calSuma(this.numeros[0], this.numeros[1]);
                        this.numeros.RemoveAt(0);
                        this.numeros.RemoveAt(0);
                        this.operadores.RemoveAt(0);
                        break;
                    case "-":
                        resultado += this.calResta(this.numeros[0], this.numeros[1]);
                        this.numeros.RemoveAt(0);
                        this.numeros.RemoveAt(0);

                        this.operadores.RemoveAt(0);
                        break;
                }
            }
            for (;this.numeros.Count>0 ; )
            {
                if (aux&&this.operadores.Count > 0)
                {
                    switch (this.operadores[0])
                    {
                        case "+":
                            resultado += this.calSuma(resultado, this.numeros[0]);
                            this.numeros.RemoveAt(0);
                            this.operadores.RemoveAt(0);
                            break;
                        case "-":
                            resultado += this.calResta(resultado, this.numeros[0]);
                            this.numeros.RemoveAt(0);
                            this.operadores.RemoveAt(0);
                            break;
                    }
                }
                
                else
                {
                    archivo += "\tEl resultado es: " + this.resultado.ToString();
                    this.saveArchivo(archivo);
                    this.archivo = "";
                    this.numeros.Add(0);
                    break;
                }
                aux = true;
                
                
            }
            archivo += "\tEl resultado es: " + this.resultado.ToString();
            this.saveArchivo(archivo);
            this.archivo = "";
            this.numeros.Add(0);
        }
        public Form1()
        {
            Calculadoras a= new Calculadoras();
            InitializeComponent();
            this.numeros = new List<double>();
            this.numeros.Add(0);
            this.operadores = new List<string>();
            this.calDiv += a.Divicion;
            this.calMult += a.Multiplicacion;
            this.calSuma += a.Suma;
            this.calResta += a.Resta;
            this.saveArchivo += a.Archivo;


        }


        private void Form1_Load(object sender, EventArgs e)
        {

            this.textBox1.AllowDrop = false;

            this.inicio();

            
        }
        void inicio()
        {
            this.CambiarOperadoresFalse();
            this.igual.Enabled = true;

            foreach (Control i in this.Controls)
            {
                i.Click += this.Mostrar;
            }
            foreach (Control i in this.panel2.Controls)
            {
                i.Click += this.Mostrar;
            }
            this.botonBorrar.Click -= this.Mostrar;
            this.igual.Click -= this.Mostrar;
        }

        public object _1 { get; set; }
    }
}
